fC2R = @(x) [real(x) imag(x)];
fR2C = @(x) complex(x(:,1), x(:,2));
mod_rap=@(x,a)(x-(ceil(x/a)-1)*a);
%%
% [x, t] = readObj('camelhead_slim');
[x, t] = readObj('blade_parametrized_nonlin_cut');
% x = fC2R(X); t = T; x(:,3) = 0;

nf = size(t, 1);
nv = size(x, 1);


%% 网格分区
edges=[t(:,1:2);t(:,2:3);t(:,[3,1])];
edges=sort(edges,2);
edges=sortrows(edges);
edges=unique(edges,"rows");
egs=[edges(:,1),edges(:,2),ones(size(edges,1),1);edges(:,2),edges(:,1),ones(size(edges,1),1)];
egs=[egs;(1:nv)',(1:nv)',ones(nv,1)];
Tapir=sparse(egs(:,1),egs(:,2),egs(:,3));
Txy=x;
map = geodice(Tapir,Txy,4);
nBlock=max(map)+1;
figure(1);
clf reset;
colordef(1,'black')
gplotmap(Tapir,Txy,map);

ne=size(edges,1);
iscutEdgeVertice=false(nv,1);
isboundVertice=false(nv,1);
iscutEdge=false(ne,1);
for i=1:ne
    if(map(edges(i,1))~=map(edges(i,2)))
        iscutEdgeVertice(edges(i,1))=true;% 切割边界点
        iscutEdgeVertice(edges(i,2))=true;
        iscutEdge(i)=true;% 切割内点
    end
end
triCast=zeros(nf,1);
for f_id=1:nf
    vert_ids=t(f_id,:);
    Map_id=map(vert_ids);
    if(Map_id(1)==Map_id(2)&&Map_id(2)==Map_id(3))
        triCast(f_id)=Map_id(1);
    else
        triCast(f_id)=-1;
    end
end


% n0=sum(map==0);
% localToglobal=zeros(n0,1);globalTolocal=zeros(nv,1);
% id=0;
% for i=1:nv
%     if map(i)==0
%         id=id+1;
%         localToglobal(id)=i;
%         globalTolocal(i)=id;
%     end
% end
% triloc=globalTolocal(t(triCast==0,:));



faceElens = sqrt( meshFaceEdgeLen2s(x, t) );
faceAngles = meshAnglesFromFaceEdgeLen2(faceElens.^2);
flatXPerFace = [zeros(nf,1) faceElens(:,3) faceElens(:,2).*exp(1i*faceAngles(:,1))];


%% initilization
L = laplacian(x, t, 'uniform');
B = findBoundary(x, t);
isboundVertice(B)=true;
I = setdiff(1:nv, B);
Areas = signedAreas(x, t);

isometric_energyies = [ "SymmDirichlet", "ExpSD", "AMIPS", "SARAP", "HOOK", "ARAP", "BARAP", "BCONF"];
hessian_projections = [ "NP", "KP", "FP4", "FP6", "CM" ];

energy_param = 1;
energy_type = isometric_energyies(1);
hession_proj = hessian_projections(2);

findStringC = @(s, names) find(strcmpi(s, names), 1) - 1;
mexoption = struct('energy_type', findStringC(energy_type, isometric_energyies), ...
                   'hessian_projection', findStringC(hession_proj, hessian_projections), ...
                   'energy_param', energy_param, 'verbose', 0);

z = zeros(nv,1);
z(B) = exp(2i*pi*(1:numel(B))'/numel(B));
z(I) = -L(I,I)\(L(I,B)*z(B));

z=z*40;

figure; h = trimesh(t, real(z), imag(z), z*0); hold on; view(2); axis equal; axis off;
set(h, 'FaceColor', 'w', 'edgealpha', 0.1, 'edgecolor', 'k');

D2 = -1i/4*(flatXPerFace(:,[2 3 1])-flatXPerFace(:,[3 1 2]))./Areas;
D = sparse(repmat(1:nf,3,1)', t, D2);
D2t = D2.';

fDeformEnergy = @(z) meshIsometricEnergyC(conj(D*conj(z)), D*z, D2t, Areas, mexoption); 

en = fDeformEnergy(z);

lambda = 1e-8;


%% initialization, get sparse matrix pattern
[xmesh, ymesh] = meshgrid(1:6, 1:6);
t2 = [t t+nv]';
Mi = t2(xmesh(:), :);
Mj = t2(ymesh(:), :);

% H = sparse(Mi, Mj, 1, nv*2, nv*2);  % only pattern is needed
H = [L L; L L];


% nonzero indices of the matrix
Hnonzeros0 = zeros(nnz(H),1);
idxDiagH = ij2nzIdxs(H, uint64(1:nv*2), uint64(1:nv*2));
Hnonzeros0(idxDiagH) = lambda*2;
nzidx = ij2nzIdxs(H, uint64(Mi), uint64(Mj));

solver = splsolver(H, 'ldlt');


% fun_meshNewtonParam(x,t,z,Areas,t2,D2,D,D2t);
%% main loop

TRI=cell(nBlock,1);area=cell(nBlock,1);weights=cell(nBlock,1);
for bl_id=1:nBlock
    TRI{bl_id}=(triCast==bl_id-1);
    area{bl_id}=repmat(logical((map==bl_id-1)'.*(~iscutEdgeVertice)),2,1);
    weights{bl_id}=Areas;
    weights{bl_id}(~(triCast==bl_id-1))=0;
end

g2GIdx = uint64(t2);

dir=zeros(nf,1);
for el_id=1:nf
    vert_ids=t(el_id,:);
    verts=z(vert_ids);
    dir(el_id)=det([1,1,1;real(verts)';imag(verts)']');
end
flit=dir>0;
for bl_id=1:nBlock
for it=1:50
    tt = tic;

    fz = conj(D*conj(z)); % equivalent but faster than conj(D)*z;
    gz = D*z;

    [e, g, hs] = meshIsometricEnergyC(fz, gz, D2t, weights{bl_id}, mexoption);

    G = accumarray(g2GIdx(:), g(:));
    Hnonzeros = accumarray( nzidx(:), hs(:) ) + Hnonzeros0;

    %% Newton
%     H = sparse(Mi, Mj, hs, nv*2, nv*2) + 2*lambda*sparse(1:nv*2, 1:nv*2, 1, nv*2, nv*2); 
    matH = replaceNonzeros(H, Hnonzeros);
    dz = zeros(nv*2,1);
    % dz(map==0) = matH(map==0,map==0) \ -G(map==0);
    % area0=(map==0)';

    dz(area{bl_id}) = matH(area{bl_id},area{bl_id})\-G(area{bl_id});
    % dz=matH\-G;
%     dz = solver.refactor_solve(Hnonzeros, -G);

    dz = fR2C( reshape(dz, [], 2) );

    %% orientation preservation
    ls_t = min( maxtForPositiveArea( fz(TRI{bl_id}), gz(TRI{bl_id}), conj(D(TRI{bl_id},:)*conj(dz)), D(TRI{bl_id},:)*dz )*0.9, 1 );

    %% line search energy decreasing
    fMyFun = @(t) fDeformEnergy( dz*t + z );
    normdz = norm(dz);

    dgdotfz = dot( G, [real(dz); imag(dz)] );

    ls_alpha = 0.2; ls_beta = 0.5;
    fQPEstim = @(t) en+ls_alpha*t*dgdotfz;

    e_new = fMyFun(ls_t);
    while ls_t*normdz>1e-12 && e_new > fQPEstim(ls_t)
        ls_t = ls_t*ls_beta;
        e_new = fMyFun(ls_t);
    end
    en = e_new;

    fprintf('it: %3d, en: %.3e, runtime: %fs, ls: %.2e, step: %.2e, |g|: %.2e\n', it, en, toc(tt), ls_t, ls_t*normdz, norm(G));

    %% update
    z = dz*ls_t + z;
%     [ min(signedAreas(z,t)) fDeformEnergy(z) ]

    %%
    title( sprintf('iter %d', it) );
    set(h, 'Vertices', fC2R(z));
    drawnow;
    pause(0.002);
end
end
colors=hsv(nBlock);
eblock=cell(nBlock,1);%meanValue=cell(nBlock,1);
figure
gplotmap(Tapir,[real(z),imag(z)],map);
hold on
meanValue=zeros(nv,nv);
for bl_id=1:nBlock
    fblock=t(TRI{bl_id},:);
    drawmesh(fblock,[real(z),imag(z)],'k');
    
    eblock{bl_id} = findBoundary(x, fblock);
    plot(real(z(eblock{bl_id}([1:end,1]))),imag(z(eblock{bl_id}([1:end,1]))),'r','LineWidth',2)
    
    vts=find(map==bl_id-1);
    for j=1:sum(map==bl_id-1)
        if ~iscutEdgeVertice(vts(j))&&~isboundVertice(vts(j))
        diR=z(eblock{bl_id})-z(vts(j));
        meanValue(vts(j),eblock{bl_id})=(tan((angle(diR([2:end,1])./diR)/2))+tan((angle(diR./diR([end,1:end-1]))/2)))./abs(diR);
        w=(tan(angle(diR([2:end,1])./diR)/2)+tan(angle(diR./diR([end,1:end-1]))/2))./abs(diR);
        if min(w)==Inf||max(w)==Inf||min(w)==-Inf||max(w)==-Inf
            error("Inf")
        end
        end
    end
end
static=iscutEdgeVertice|isboundVertice;
% free=iscutEdgeVertice;
free=static;
isfree=false(nv,1);
isfree(free)=true;
isfree=isfree(static);

meanValue(static,static)=eye(sum(static));
meanValue=meanValue./sum(meanValue,2);
meanValue=meanValue(:,static);
Ze=zeros(size(meanValue,1),size(meanValue,2));
meanValue=[meanValue,Ze;Ze,meanValue];
meanValue=sparse(meanValue);
Isfree=[isfree;isfree];
% figure
% gplotmap(Tapir,[real(z),imag(z)],map);
for it=1:50
    tt = tic;

    fz = conj(D*conj(z)); % equivalent but faster than conj(D)*z;
    gz = D*z;
    
    [e, g, hs] = meshIsometricEnergyC(fz, gz, D2t, Areas, mexoption);

    G = accumarray(g2GIdx(:), g(:));
    Gstatic = meanValue' * G;
    Hnonzeros = accumarray( nzidx(:), hs(:) ) + Hnonzeros0;
    
    %% Newton
%     H = sparse(Mi, Mj, hs, nv*2, nv*2) + 2*lambda*sparse(1:nv*2, 1:nv*2, 1, nv*2, nv*2); 
    matH = meanValue' * replaceNonzeros(H, Hnonzeros) * meanValue;
    % dz(map==0) = matH(map==0,map==0) \ -G(map==0);
    % area0=(map==0)';
    
    dzstatic = zeros(nv,1);
    matH = matH(Isfree,Isfree);
    dzstatic([free;free]) = matH \ -Gstatic(Isfree);
    dz = meanValue * dzstatic([static;static]);
    % dz=matH\-G;
%     dz = solver.refactor_solve(Hnonzeros, -G);

    dz = fR2C( reshape(dz, [], 2) );
    
    %% orientation preservation
    ls_t = min( maxtForPositiveArea( fz, gz, conj(D*conj(dz)), D*dz )*0.9, 1 );

    %% line search energy decreasing
    fMyFun = @(t) fDeformEnergy( dz*t + z );
    normdz = norm(dz);

    dgdotfz = dot( G, [real(dz); imag(dz)] );
    
    ls_alpha = 0.2; ls_beta = 0.5;
    fQPEstim = @(t) en+ls_alpha*t*dgdotfz;

    e_new = fMyFun(ls_t);
    while ls_t*normdz>1e-12 && e_new > fQPEstim(ls_t)
        ls_t = ls_t*ls_beta;
        e_new = fMyFun(ls_t);
    end
    en = e_new;
    
    fprintf('it: %3d, en: %.3e, runtime: %fs, ls: %.2e, step: %.2e, |g|: %.2e\n', it, en, toc(tt), ls_t, ls_t*normdz, norm(G));
    
    %% update
    z = dz*ls_t + z;
%     [ min(signedAreas(z,t)) fDeformEnergy(z) ]

    %%
    title( sprintf('iter %d', it) );
    set(h, 'Vertices', fC2R(z));
    drawnow;
    pause(0.002);
end