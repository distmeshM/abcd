function [x,t]=fun_meshNewtonParam(x,t,z,Areas,t2,D2,D,D2t)


fC2R = @(x) [real(x) imag(x)];
fR2C = @(x) complex(x(:,1), x(:,2));

%%
% x = fC2R(X); t = T; x(:,3) = 0;

nf = size(t, 1);
nv = size(x, 1);

faceElens = sqrt( meshFaceEdgeLen2s(x, t) );
faceAngles = meshAnglesFromFaceEdgeLen2(faceElens.^2);
flatXPerFace = [zeros(nf,1) faceElens(:,3) faceElens(:,2).*exp(1i*faceAngles(:,1))];


%% initilization


%% main loop
g2GIdx = uint64(t2);
for it=1:1000
    tt = tic;

    fz = conj(D*conj(z)); % equivalent but faster than conj(D)*z;
    gz = D*z;
    [e, g, hs] = meshIsometricEnergyC(fz, gz, D2t, Areas, mexoption);

    G = accumarray(g2GIdx(:), g(:));
    Hnonzeros = accumarray( nzidx(:), hs(:) ) + Hnonzeros0;
    
    %% Newton
%     H = sparse(Mi, Mj, hs, nv*2, nv*2) + 2*lambda*sparse(1:nv*2, 1:nv*2, 1, nv*2, nv*2);    
    dz = replaceNonzeros(H, Hnonzeros) \ -G;
%     dz = solver.refactor_solve(Hnonzeros, -G);

    dz = fR2C( reshape(dz, [], 2) );
    
    %% orientation preservation
    ls_t = min( maxtForPositiveArea( fz, gz, conj(D*conj(dz)), D*dz )*0.9, 1 );

    %% line search energy decreasing
    fMyFun = @(t) fDeformEnergy( dz*t + z );
    normdz = norm(dz);

    dgdotfz = dot( G, [real(dz); imag(dz)] );
    
    ls_alpha = 0.2; ls_beta = 0.5;
    fQPEstim = @(t) en+ls_alpha*t*dgdotfz;

    e_new = fMyFun(ls_t);
    while ls_t*normdz>1e-12 && e_new > fQPEstim(ls_t)
        ls_t = ls_t*ls_beta;
        e_new = fMyFun(ls_t);
    end
    en = e_new;
    
    fprintf('it: %3d, en: %.3e, runtime: %fs, ls: %.2e, step: %.2e, |g|: %.2e\n', it, en, toc(tt), ls_t, ls_t*normdz, norm(G));
    
    %% update
    z = dz*ls_t + z;
%     [ min(signedAreas(z,t)) fDeformEnergy(z) ]

    %%
    title( sprintf('iter %d', it) );
    set(h, 'Vertices', fC2R(z));
    drawnow;
    pause(0.002);
end
end

